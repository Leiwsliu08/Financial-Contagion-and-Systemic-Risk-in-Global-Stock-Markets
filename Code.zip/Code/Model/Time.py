import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import timedelta
import ace_tools as tools

# Define data paths
stock_data_path = "C:\\Users\\24545\\Desktop\\Data\\reaction\\All_Stock_Data.csv"
events_data_path = "C:\\Users\\24545\\Desktop\\Data\\reaction\\Events_Data.csv"

# Read CSV files
stock_data = pd.read_csv(stock_data_path)
events_data = pd.read_csv(events_data_path)

# Convert date columns to datetime format
stock_data['Date'] = pd.to_datetime(stock_data['Date'])
events_data['Event_Date'] = pd.to_datetime(events_data['Event_Date'])

# Convert the 'Close' column to numeric type
stock_data['Close'] = pd.to_numeric(stock_data['Close'], errors='coerce')

# Append the region to the company name as a suffix
stock_data['Company_Region'] = stock_data['Company'] + " (" + stock_data['Region'] + ")"

# Define the length of the event window, e.g., 5 days before and after
window_days = 5

# Initialize a list to store results
response_times = []

# Analyze each event
for _, event in events_data.iterrows():
    event_date = event['Event_Date']
    event_description = event['Event_Description']

    # Select stock data within the event window
    event_window_start = event_date - timedelta(days=window_days)
    event_window_end = event_date + timedelta(days=window_days)

    # Filter the stock data within the event window
    event_window_data = stock_data[
        (stock_data['Date'] >= event_window_start) & (stock_data['Date'] <= event_window_end)]

    # Analyze each company
    for company in event_window_data['Company_Region'].unique():
        company_data = event_window_data[event_window_data['Company_Region'] == company]

        # Calculate stock changes within the event window (relative change in closing price)
        company_data = company_data.sort_values('Date')
        company_data['Price_Change'] = company_data['Close'].pct_change()

        # Remove NaN values
        company_data = company_data.dropna(subset=['Price_Change'])

        # Skip the company if there's no valid data
        if company_data.empty:
            continue

        # Calculate cumulative returns
        company_data['Cumulative_Change'] = company_data['Price_Change'].cumsum()

        # Find the date with the maximum cumulative change, marking the response time
        max_change_date = company_data.loc[company_data['Cumulative_Change'].idxmax(), 'Date']

        # Record the result
        response_times.append({
            'Event': event_description,
            'Company': company,
            'Max_Change_Date': max_change_date,
            'Days_After_Event': (max_change_date - event_date).days
        })

# Convert results to a DataFrame
response_df = pd.DataFrame(response_times)

# Sort by response time
response_df = response_df.sort_values(by=['Event', 'Days_After_Event'])

# Display the results
tools.display_dataframe_to_user(name="Stock Response Analysis with Region", dataframe=response_df)

# Visualization: Create a bar chart for each event
for event in response_df['Event'].unique():
    event_data = response_df[response_df['Event'] == event]
    plt.figure(figsize=(10, 6))
    plt.barh(event_data['Company'], event_data['Days_After_Event'], color='skyblue')
    plt.xlabel('Days After Event')
    plt.ylabel('Company')
    plt.title(f'Stock Response Time for Event: {event}')
    plt.show()