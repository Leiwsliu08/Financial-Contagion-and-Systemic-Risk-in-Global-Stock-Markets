import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# Load data
events_data = pd.read_csv('C:\\Users\\24545\\Desktop\\Data\\reaction\\Events_Data.csv')
stock_data = pd.read_csv('C:\\Users\\24545\\Desktop\\Data\\reaction\\All_Stock_Data.csv')

# Convert date columns to datetime format
events_data['Event_Date'] = pd.to_datetime(events_data['Event_Date'])
stock_data['Date'] = pd.to_datetime(stock_data['Date'])

# Set the event window (e.g., 5 days before and after the event)
window_days = 5

# Extract stock data around the event window
event_impact_data = {}
for index, event in events_data.iterrows():
    event_date = event['Event_Date']
    event_name = event['Event_Description']

    # Filter data within the event window
    stock_data_window = stock_data[
        (stock_data['Date'] >= event_date - pd.Timedelta(days=window_days)) &
        (stock_data['Date'] <= event_date + pd.Timedelta(days=window_days))
    ]

    event_impact_data[event_name] = stock_data_window

# Calculate price changes
price_changes = {}
for event_name, stock_data_window in event_impact_data.items():
    stock_data_window['Close'] = pd.to_numeric(stock_data_window['Close'], errors='coerce')
    stock_data_window = stock_data_window.dropna(subset=['Close'])
    stock_data_window = stock_data_window[~stock_data_window['Company'].str.contains('Unnamed', na=False)]
    stock_data_window = stock_data_window.sort_values(by='Date')
    stock_data_window['Price_Change'] = stock_data_window.groupby('Company')['Close'].pct_change() * 100
    price_changes[event_name] = stock_data_window

# Extract correlation matrix
event_name = next(iter(price_changes))
price_change_data = price_changes[event_name]
price_change_pivot = price_change_data.pivot(index='Date', columns='Company', values='Price_Change')
correlation_matrix = price_change_pivot.corr()

# Build the network graph
G = nx.Graph()
threshold = 0.5
for company in correlation_matrix.columns:
    G.add_node(company)
for company1 in correlation_matrix.columns:
    for company2 in correlation_matrix.columns:
        if company1 != company2 and abs(correlation_matrix.loc[company1, company2]) > threshold:
            G.add_edge(company1, company2, weight=correlation_matrix.loc[company1, company2])

# Calculate degree centrality of nodes
degree_centrality = nx.degree_centrality(G)
node_sizes = [degree_centrality[node] * 1000 for node in G.nodes()]
edge_weights = nx.get_edge_attributes(G, 'weight')
max_weight = max(edge_weights.values())
normalized_weights = {k: v / max_weight for k, v in edge_weights.items()}

# Plot the network graph
plt.figure(figsize=(12, 12))
# pos = nx.spring_layout(G, seed=42)
pos = nx.shell_layout(G)
nx.draw_networkx_edges(G, pos, edge_color='gray', width=[normalized_weights[edge] * 1 for edge in G.edges()])
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color='lightblue', alpha=0.8)
nx.draw_networkx_labels(G, pos, font_size=10, font_weight='bold')
plt.title("Enhanced Financial Contagion Network", fontsize=15)
plt.show()