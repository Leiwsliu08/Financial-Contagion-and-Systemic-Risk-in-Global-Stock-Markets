import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import random

# Load the data
stock_data = pd.read_csv('C:\\Users\\24545\\Desktop\\Data\\reaction\\All_Stock_Data.csv')
events_data = pd.read_csv('C:\\Users\\24545\\Desktop\\Data\\reaction\\Events_Data.csv')

# Step 1: Data Cleaning and Processing
# Convert 'Date' column to datetime
stock_data['Date'] = pd.to_datetime(stock_data['Date'])

# Convert 'Close' column to numeric, coercing errors to NaN
stock_data['Close'] = pd.to_numeric(stock_data['Close'], errors='coerce')

# Drop rows with NaN values in 'Close'
stock_data_cleaned = stock_data.dropna(subset=['Close'])

# Calculate daily returns
stock_data_cleaned = stock_data_cleaned.sort_values(by=['Company', 'Date'])
stock_data_cleaned['Return'] = stock_data_cleaned.groupby('Company')['Close'].pct_change()

# Drop NaN values in 'Return'
stock_data_cleaned = stock_data_cleaned.dropna(subset=['Return'])

# Step 2: Create Correlation Matrix
returns_pivot = stock_data_cleaned.pivot(index='Date', columns='Company', values='Return')
correlation_matrix_cleaned = returns_pivot.corr()

# Step 3: Build the Network Model
G = nx.Graph()
companies = correlation_matrix_cleaned.columns
G.add_nodes_from(companies)

# Add edges with a correlation threshold (0.5 initially)
threshold = 0.5
for i, company1 in enumerate(companies):
    for j, company2 in enumerate(companies):
        if i < j:
            correlation_value = correlation_matrix_cleaned.loc[company1, company2]
            if correlation_value > threshold:
                G.add_edge(company1, company2, weight=correlation_value)

# Visualize the network
pos = nx.spring_layout(G)
plt.figure(figsize=(12, 12))
nx.draw_networkx(G, pos, with_labels=True, node_size=500, font_size=10, edge_color='b', alpha=0.7)
plt.title("Financial Network of Companies based on Correlation")
plt.show()

# Step 4: Contagion Simulation
def simulate_contagion(G, initial_infected, steps=10, infection_threshold=0.5):
    infected = set(initial_infected)
    infected_timeline = [set(infected)]
    for _ in range(steps):
        new_infected = set()
        for node in infected:
            for neighbor in G.neighbors(node):
                if neighbor not in infected and G[node][neighbor]['weight'] >= infection_threshold:
                    new_infected.add(neighbor)
        infected.update(new_infected)
        infected_timeline.append(set(infected))
    return infected_timeline

# Step 5: Simulate contagion with a lower threshold (0.3)
lower_threshold = 0.3
initial_company = random.choice(list(companies))
infected_timeline_lower_threshold = simulate_contagion(G, initial_infected=[initial_company], infection_threshold=lower_threshold)

# Extract results for visualization
infected_timeline_summary_lower_threshold = [len(infected) for infected in infected_timeline_lower_threshold]

# Step 6: Visualization of contagion spread
def plot_contagion_timeline(timeline, title="Contagion Spread Over Time"):
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(timeline)), timeline, marker='o')
    plt.title(title)
    plt.xlabel("Time Step")
    plt.ylabel("Number of Infected Companies")
    plt.grid(True)
    plt.show()

plot_contagion_timeline(infected_timeline_summary_lower_threshold, title="Contagion Spread with Lower Threshold (0.3)")