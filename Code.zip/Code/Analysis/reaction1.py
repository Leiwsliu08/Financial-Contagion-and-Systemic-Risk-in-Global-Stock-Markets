import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load stock data and historical event data
eur_data = pd.read_excel(r'C:\Users\24545\Desktop\Data\reaction\EUR.xlsx')
ru_data = pd.read_excel(r'C:\Users\24545\Desktop\Data\reaction\RU.xlsx')
sa_data = pd.read_excel(r'C:\Users\24545\Desktop\Data\reaction\SA.xlsx')
usa_data = pd.read_excel(r'C:\Users\24545\Desktop\Data\reaction\USA.xlsx')
events_data = pd.read_excel(r'C:\Users\24545\Desktop\Data\reaction\events.xlsx')

# Clean stock data
def clean_stock_data(df, region):
    date_col = df.columns[0]
    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')

    companies = df.columns[1::3]  # Extract company names every 3 columns
    cleaned_data = pd.DataFrame()

    for company in companies:
        company_data = df[[date_col, company]].dropna().copy()
        company_data.columns = ['Date', 'Close']
        company_data['Company'] = company
        company_data['Region'] = region
        cleaned_data = pd.concat([cleaned_data, company_data], ignore_index=True)

    return cleaned_data

# Clean stock data for all regions
eur_cleaned = clean_stock_data(eur_data, 'EUR')
ru_cleaned = clean_stock_data(ru_data, 'RU')
sa_cleaned = clean_stock_data(sa_data, 'SA')
usa_cleaned = clean_stock_data(usa_data, 'USA')

# Combine all stock data
all_stock_data = pd.concat([eur_cleaned, ru_cleaned, sa_cleaned, usa_cleaned], ignore_index=True)

# Clean event data
events_data_cleaned = events_data[['Unnamed: 8', 'Unnamed: 1']].dropna().copy()
events_data_cleaned.columns = ['Event_Date', 'Event_Description']
events_data_cleaned['Event_Date'] = pd.to_datetime(events_data_cleaned['Event_Date'], errors='coerce')

# Set the time window (e.g., 7 days before and after the event)
window = 7

# Create an empty dictionary to store reaction times for each event
reaction_times = {}

for _, event in events_data_cleaned.iterrows():
    event_date = event['Event_Date']
    event_description = event['Event_Description']

    reaction_times[event_description] = {}

    for company in all_stock_data['Company'].unique():
        company_data = all_stock_data[all_stock_data['Company'] == company]

        event_window_data = company_data[(company_data['Date'] >= event_date - pd.Timedelta(days=window)) &
                                         (company_data['Date'] <= event_date + pd.Timedelta(days=window))]

        if not event_window_data.empty:
            event_window_data['Close'] = pd.to_numeric(event_window_data['Close'], errors='coerce')
            event_window_data.dropna(subset=['Close'], inplace=True)
            event_window_data['Price_Change'] = event_window_data['Close'].pct_change()

            if not event_window_data['Price_Change'].empty:
                max_change_day = event_window_data.loc[event_window_data['Price_Change'].abs().idxmax()]
                reaction_day = (max_change_day['Date'] - event_date).days
                reaction_times[event_description][company] = reaction_day

# Convert results to a DataFrame
reaction_df = pd.DataFrame(reaction_times)

# Improved visualization - Plot separately for each event
fig, axes = plt.subplots(len(reaction_df.columns), 1, figsize=(12, len(reaction_df.columns) * 4), sharex=True)
colors = plt.cm.get_cmap('tab10', len(reaction_df.columns))

for i, (event, ax) in enumerate(zip(reaction_df.columns, axes)):
    reaction_df[event].sort_values().plot(kind='barh', ax=ax, color=colors(i))
    ax.set_title(f'Reaction Times to {event}')
    ax.set_xlabel('Reaction Time (Days)')
    ax.set_ylabel('Company')

plt.tight_layout()
plt.show()