# Fix the plotting issue by plotting the time series for each cluster
# To simplify the plotting, we'll average the time series within each cluster and plot the average curve

time_series_data_grouped_mean = time_series_data.groupby(['Date', 'Cluster']).mean().reset_index()

# Plot the time series for each cluster
plt.figure(figsize=(12, 8))
for cluster in time_series_data_grouped_mean['Cluster'].unique():
    cluster_data = time_series_data_grouped_mean[time_series_data_grouped_mean['Cluster'] == cluster]
    plt.plot(cluster_data['Date'], cluster_data.iloc[:, 2:].mean(axis=1), label=f'Cluster {cluster}')

plt.title('Time Series Clusters of Market Movements')
plt.xlabel('Date')
plt.ylabel('Average Normalized Price Change')
plt.legend()
plt.show()