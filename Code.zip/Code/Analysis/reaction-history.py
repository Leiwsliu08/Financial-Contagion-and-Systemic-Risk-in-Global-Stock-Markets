# We only need to calculate the mean price changes by region and visualize it
cross_region_mean_changes = {}

# Iterate through each event to calculate the mean price change by region
for event, df in analysis_dfs.items():
    if not df.empty:
        # Calculate the mean price change rate by region
        region_mean_changes = df.groupby('Region')['Mean_Price_Change'].mean()
        cross_region_mean_changes[event] = region_mean_changes

# Visualization: Select one event and plot the cross-region contagion effect chart
event_to_visualize = list(cross_region_mean_changes.keys())[0]
region_mean_changes = cross_region_mean_changes[event_to_visualize]

plt.figure(figsize=(10, 6))
region_mean_changes.plot(kind='bar', color='skyblue')
plt.title(f'Cross-Region Mean Price Change for {event_to_visualize}')
plt.ylabel('Mean Price Change')
plt.xlabel('Region')
plt.show()