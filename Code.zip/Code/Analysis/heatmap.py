'''file_path = 'C:\\/Users/24545/Desktop/Data/USA-hot2.xlsx'''
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load the data from the uploaded Excel file
file_path = 'C:\\/Users/24545/Desktop/Data/USA-hot2.xlsx'
data = pd.read_excel(file_path, sheet_name=None)

# Assuming the data is in the first sheet
sheet_name = list(data.keys())[0]
df_hot_new = data[sheet_name]

# Extract dates
dates = pd.to_datetime(df_hot_new['Date'])

# Rename columns for simplicity
df_hot_new.columns = ['Date', 'company1', 'company2', 'company3', 'company4', 'company5']

# Drop the first row which contains duplicate headers
df_cleaned = df_hot_new.drop([0]).reset_index(drop=True)

# Re-extract dates after cleaning
dates = pd.to_datetime(df_cleaned['Date'])

# Extract close prices for each company
data_close = df_cleaned[['company1', 'company2', 'company3', 'company4', 'company5']]

# Set dates as index
data_close.index = dates

# Check for any non-numeric values
print("NaN values in each column before dropping NaNs:")
print(data_close.isna().sum())

# Drop rows with NaN values
data_close.dropna(inplace=True)

# Check data types
print("Data types:")
print(data_close.dtypes)

# Check for any non-numeric values after dropping NaNs
print("NaN values in each column after dropping NaNs:")
print(data_close.isna().sum())

# Calculate daily returns
returns = data_close.pct_change().dropna()

# Ensure there is enough data for returns calculation
print("Number of rows in returns:")
print(len(returns))

# Check returns data
print("Returns data:")
print(returns.head())

# Calculate correlation matrix
correlation_matrix = returns.corr()

# Check correlation matrix
print("Correlation matrix:")
print(correlation_matrix)

# Plot heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
plt.title('Correlation Heatmap of 5 Companies')
plt.show()