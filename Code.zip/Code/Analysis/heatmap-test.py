import pandas as pd

# Load the data from the uploaded Excel file
file_path = 'C:\\/Users/24545/Desktop/Data/USA-hot2.xlsx'
data = pd.read_excel(file_path, sheet_name=None)

# Assuming the data is in the first sheet
sheet_name = list(data.keys())[0]
df_hot_new = data[sheet_name]

# Display the first few rows to understand its structure
print("Initial data:")
print(df_hot_new.head())

# Display data types
print("\nData types:")
print(df_hot_new.dtypes)

# Display statistics of the data
print("\nData statistics:")
print(df_hot_new.describe())