import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# First, extract the price time series data for all companies and standardize it for clustering analysis
time_series_data = stock_data.pivot_table(index='Date', columns=['Company', 'Region'], values='Close').pct_change().dropna()

# Standardize the data for clustering analysis
scaler = StandardScaler()
time_series_scaled = scaler.fit_transform(time_series_data)

# Use KMeans clustering to analyze the synchronization of market movements, assuming we use 4 clusters
kmeans = KMeans(n_clusters=4, random_state=42)
clusters = kmeans.fit_predict(time_series_scaled)

# Add the clustering results back to the time series data
time_series_data['Cluster'] = clusters

# Visualize the time series for each cluster
time_series_data_grouped = time_series_data.groupby('Cluster').mean()

# Plot the time series for each cluster
plt.figure(figsize=(12, 8))
for cluster in time_series_data_grouped.index:
    plt.plot(time_series_data_grouped.columns, time_series_data_grouped.loc[cluster], label=f'Cluster {cluster}')

plt.title('Time Series Clusters of Market Movements')
plt.xlabel('Date')
plt.ylabel('Average Normalized Price Change')
plt.legend()
plt.show()