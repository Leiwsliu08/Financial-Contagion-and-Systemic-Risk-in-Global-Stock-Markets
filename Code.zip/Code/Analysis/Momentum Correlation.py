# Momentum Correlation Analysis: We will calculate the momentum of different markets and analyze their correlations.
# Momentum can be represented by the rolling average of returns, and we'll use the same window period as volatility.

# Calculate the rolling momentum (30-day average) for each company's returns
momentum = stock_data.pivot_table(index='Date', columns=['Company', 'Region'], values='Close').pct_change().rolling(window=volatility_window).mean()

# Calculate the average momentum for each region
region_momentum = momentum.groupby(level='Region', axis=1).mean()

# Calculate the momentum correlation between different regions
momentum_correlation = region_momentum.corr()

# Visualize the momentum correlation matrix between different regions
plt.figure(figsize=(8, 6))
sns.heatmap(momentum_correlation, annot=True, cmap='coolwarm', fmt='.2f')
plt.title(f'Momentum Correlation between Regions (Window = {volatility_window} days)')
plt.show()