# Calculate Volatility: Volatility is usually measured using standard deviation.
# We will calculate the volatility for each market on each date by computing the rolling standard deviation of the returns (price changes) for each company.

# Set the time window for volatility calculation
volatility_window = 30

# Calculate the rolling volatility of each company on each date
volatility = stock_data.pivot_table(index='Date', columns=['Company', 'Region'], values='Close').pct_change().rolling(window=volatility_window).std()

# Calculate the average volatility for each region
region_volatility = volatility.groupby(level='Region', axis=1).mean()

# Visualize the average volatility of each region, observing volatility clustering
plt.figure(figsize=(12, 8))
for region in region_volatility.columns:
    plt.plot(region_volatility.index, region_volatility[region], label=region)

plt.title(f'Region-wise Market Volatility (Window = {volatility_window} days)')
plt.xlabel('Date')
plt.ylabel('Volatility (Standard Deviation)')
plt.legend()
plt.show()