# Generate the correlation matrix between companies and visualize it
company_correlation_results = {}

for event, df in analysis_dfs.items():
    # Calculate the correlation matrix of the average price change rates between companies
    if not df.empty:
        pivot_table = df.pivot(index='Company', columns='Region', values='Mean_Price_Change')
        correlation_matrix = pivot_table.corr()  # Calculate the correlation matrix between companies
        company_correlation_results[event] = correlation_matrix

# Visualization: Select one event and plot the company correlation heatmap
event_to_visualize = list(company_correlation_results.keys())[0]
correlation_matrix = company_correlation_results[event_to_visualize]

plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title(f'Company Correlation Matrix for {event_to_visualize}')
plt.show()