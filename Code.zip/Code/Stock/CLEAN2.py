import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import numpy as np


pd.set_option('future.no_silent_downcasting', True)

# Load the datasets
eur_df = pd.read_excel('C:\\/Users/24545/Desktop/Data/EUR.xlsx')
sa_df = pd.read_excel('C:\\/Users/24545/Desktop/Data/SA.xlsx')
usa_df = pd.read_excel('C:\\/Users/24545/Desktop/Data/USA.xlsx')


# Function to clean and extract relevant data (Date and Close columns)
def clean_data(df):
    cleaned_data = {}
    columns = df.columns

    # Loop through the columns to find pairs of (Date, Close) columns
    for i in range(0, len(columns) - 1, 3):
        company_name = columns[i + 1]
        date_col = columns[i]
        close_col = columns[i + 1]

        # Drop rows where the date column is "Date"
        company_data = df[[date_col, close_col]].dropna()
        company_data = company_data[company_data[date_col] != "Date"]
        company_data.columns = ['Date', company_name]

        # Convert the Date column to datetime
        company_data['Date'] = pd.to_datetime(company_data['Date'], errors='coerce')
        company_data = company_data.dropna()  # Drop any rows where date conversion failed

        # Add to dictionary
        cleaned_data[company_name] = company_data.set_index('Date')

    return cleaned_data


# Clean the datasets using the updated function
eur_cleaned = clean_data(eur_df)
sa_cleaned = clean_data(sa_df)
usa_cleaned = clean_data(usa_df)

# Combine all cleaned data into one DataFrame
all_data = pd.concat([eur_cleaned[key] for key in eur_cleaned] +
                     [sa_cleaned[key] for key in sa_cleaned] +
                     [usa_cleaned[key] for key in usa_cleaned], axis=1)

# Fill missing values with the previous day's close (forward fill)
all_data = all_data.ffill().infer_objects(copy=False)

# Remove columns that are entirely NaN
all_data = all_data.dropna(axis=1, how='all')

# Scale the data using MinMaxScaler
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(all_data)

# Convert the scaled data back to DataFrame for easier manipulation
scaled_data = pd.DataFrame(scaled_data, index=all_data.index, columns=all_data.columns)

# Specify the path to save the cleaned and scaled data
save_path = 'C:\\/Users/24545/Desktop/Data/Clean/Clean'  # Replace with your desired path

# Save the processed data as CSV files
scaled_data.to_csv(f'{save_path}scaled_stock_data.csv')


# Generate the sequences for LSTM
def create_sequences(data, seq_length, forecast_horizon):
    X = []
    y = []
    for i in range(seq_length, len(data) - forecast_horizon):
        X.append(data[i - seq_length:i])
        y.append(data[i:i + forecast_horizon])
    return np.array(X), np.array(y)


# Define sequence length and forecast horizon
SEQ_LENGTH = 60  # Use the last 60 days to predict the next 5 days
FORECAST_HORIZON = 3  # Predict the next 5 days

# Generate the sequences
X, y = create_sequences(scaled_data.values, SEQ_LENGTH, FORECAST_HORIZON)

# Reshape y to match the desired output shape for multi-task learning
y = y.reshape(y.shape[0], FORECAST_HORIZON, scaled_data.shape[1])

# Save processed data for training
np.save(f'{save_path}X.npy', X)
np.save(f'{save_path}y.npy', y)