import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter, MonthLocator

# 读取Excel文件
sa_df = pd.read_excel('C:\\/Users/24545/Desktop/Data/SA.xlsx', header=1)


# 提取数据并绘制图表
plt.figure(figsize=(30, 8))

# SA数据中的十家公司
plt.plot(sa_df['Date'], sa_df['Close'], label='Saudi Aramco')
plt.plot(sa_df['Date.1'], sa_df['Close.1'], label='SABIC')
plt.plot(sa_df['Date.2'], sa_df['Close.2'], label='SEC')
plt.plot(sa_df['Date.3'], sa_df['Close.3'], label='GASCO')
plt.plot(sa_df['Date.4'], sa_df['Close.4'], label='Petro Rabigh')
plt.plot(sa_df['Date.5'], sa_df['Close.5'], label='Saudi Kayan Petrochemical Company')
plt.plot(sa_df['Date.6'], sa_df['Close.6'], label='Yanpet')
plt.plot(sa_df['Date.7'], sa_df['Close.7'], label='Tasnee')
plt.plot(sa_df['Date.8'], sa_df['Close.8'], label='Sipchem')
plt.plot(sa_df['Date.9'], sa_df['Close.9'], label='APC')

plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('Stock Prices of 10 Companies in SA Over Time')
plt.legend(bbox_to_anchor=(0.95, 1.0085), loc='upper left')
plt.grid(True)

# 设置时间格式为按季度显示
plt.gca().xaxis.set_major_locator(MonthLocator(bymonth=[1, 4, 7, 10]))
plt.gca().xaxis.set_major_formatter(DateFormatter("%Y-%m"))

# 设置x轴范围为2013年至2023年
plt.xlim(pd.Timestamp('2013-01-01'), pd.Timestamp('2023-12-31'))

plt.xticks(rotation=45)

plt.show()