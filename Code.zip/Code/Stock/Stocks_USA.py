import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter, MonthLocator

# 读取Excel文件
usa_df = pd.read_excel('C:\\/Users/24545/Desktop/Data/USA.xlsx', header=1)

# 过滤数据，只保留2013年至2023年的数据
usa_df_filtered = usa_df[(pd.to_datetime(usa_df['Date']) >= '2013-01-01') & (pd.to_datetime(usa_df['Date']) < '2024-01-01')]

# 提取数据并绘制图表
plt.figure(figsize=(35, 8))

# USA数据中的十家公司
plt.plot(pd.to_datetime(usa_df_filtered['Date']), usa_df_filtered['Close'], label='EXXON MOBIL')
plt.plot(pd.to_datetime(usa_df_filtered['Date.1']), usa_df_filtered['Close.1'], label='CHEVRON CORP')
plt.plot(pd.to_datetime(usa_df_filtered['Date.2']), usa_df_filtered['Close.2'], label='CONOCOPHILLIPS')
plt.plot(pd.to_datetime(usa_df_filtered['Date.3']), usa_df_filtered['Close.3'], label='EOG RESOURCES')
plt.plot(pd.to_datetime(usa_df_filtered['Date.4']), usa_df_filtered['Close.4'], label='PIONEER NATURAL RESOURCES')
plt.plot(pd.to_datetime(usa_df_filtered['Date.5']), usa_df_filtered['Close.5'], label='PHILLIPS 66')
plt.plot(pd.to_datetime(usa_df_filtered['Date.6']), usa_df_filtered['Close.6'], label='OCCIDENTAL PETROLEUM')
plt.plot(pd.to_datetime(usa_df_filtered['Date.7']), usa_df_filtered['Close.7'], label='VALERO ENERGY')
plt.plot(pd.to_datetime(usa_df_filtered['Date.8']), usa_df_filtered['Close.8'], label='MARATHON PETROLEUM')
plt.plot(pd.to_datetime(usa_df_filtered['Date.9']), usa_df_filtered['Close.9'], label='HESS CORPORATION')

plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('Stock Prices of 10 Companies in USA Over Time')
plt.legend(bbox_to_anchor=(1, 1.16), loc='upper left')
plt.grid(True)

# 设置时间格式为按季度显示
plt.gca().xaxis.set_major_locator(MonthLocator(bymonth=[1, 4, 7, 10]))
plt.gca().xaxis.set_major_formatter(DateFormatter("%Y-%m"))

# 设置x轴范围为2013年至2023年
plt.xlim(pd.Timestamp('2013-01-01'), pd.Timestamp('2023-12-31'))

plt.xticks(rotation=45)

plt.show()