import pandas as pd
import numpy as np

# Load the CSV file
file_path = 'C:\\/Users/24545/Desktop/Data/Clean/Cleanscaled_stock_data.csv'  # Replace with your file path
data = pd.read_csv(file_path)

# Separate the date column and numeric columns
date_column = data['Date']
numeric_data = data.drop(columns=['Date'])

# Remove rows containing NaN values
def remove_nan_rows(data):
    return data.dropna()

# Fill NaN values with the mean of the column
def fill_nan_with_mean(data):
    return data.fillna(data.mean())

# numeric_data = remove_nan_rows(numeric_data)
numeric_data = fill_nan_with_mean(numeric_data)

# Check if there are any NaN values left in the processed data
contains_nan = numeric_data.isna().any().any()

if not contains_nan:
    print("No NaN values found in the numeric columns after processing.")
    # Recombine the date column with the processed numeric columns
    processed_data = pd.concat([date_column, numeric_data], axis=1)
    # Save the processed data
    processed_file_path = 'C:\\/Users/24545/Desktop/Data/Predict/Cleanscaled_stock_data_processed.csv'  # Replace with your desired save path
    processed_data.to_csv(processed_file_path, index=False)
else:
    print("NaN values still exist in the numeric data after processing.")