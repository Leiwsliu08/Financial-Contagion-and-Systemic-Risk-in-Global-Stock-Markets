import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

# Load the Excel file
file_path = 'C:\\/Users/24545/Desktop/Data/RU.xlsx'
data = pd.read_excel(file_path)

# Clean the data, select relevant columns, and rename them
data_cleaned = data.iloc[1:, [0, 1, 4, 7, 10, 13, 16, 19, 22, 25, 28]].copy()
data_cleaned.columns = ['Date', 'Gazprom', 'Rosneft', 'Lukoil', 'Novatek',
                        'Transneft', 'Surgutneftegas', 'Tatneft',
                        'Inter RAO', 'Bashneft', 'Slavneft']

# Convert the 'Date' column to datetime format
data_cleaned['Date'] = pd.to_datetime(data_cleaned['Date'])

# Convert the other columns to numeric type, setting non-convertible values to NaN
for col in data_cleaned.columns[1:]:
    data_cleaned[col] = pd.to_numeric(data_cleaned[col], errors='coerce')

# Remove rows with NaN values
data_cleaned.dropna(inplace=True)

# Standardize the stock price data
scaler = StandardScaler()
standardized_data = data_cleaned.copy()
standardized_data.iloc[:, 1:] = scaler.fit_transform(data_cleaned.iloc[:, 1:])

# Plot the standardized stock prices over time
plt.figure(figsize=(14, 8))

for col in standardized_data.columns[1:]:
    plt.plot(standardized_data['Date'], standardized_data[col], label=col)

plt.title('Standardized Stock Prices Over Time')
plt.xlabel('Date')
plt.ylabel('Standardized Price')
plt.legend(loc='best')
plt.grid(True)
plt.show()